//
//  BonjourService.swift
//  BonjourMulticast
//
//  Created by Gowri on 14/07/20.
//  Copyright © 2020 Sample. All rights reserved.
//

import UIKit

//BonjourDelegate
protocol BonjourDelegate {
    func publishService(_ body: NetService?)
    func scanService()
}

// Service param
enum serviceValue : String{
    case domain = "local."
    case type = "_http._tcp."
}
//MARK:- Bonjour Service Object
class BonjourService: NSObject, NetServiceDelegate, NetServiceBrowserDelegate{
    
    var delegate: BonjourDelegate!
    var devices = [NetService]()
    var coServiceBrowser: NetServiceBrowser!
    var service: NetService!
    static let portAddr = 8080
    var publishEnabled = Bool()
    
    override init() {
        super.init()
    }
    
    //MARK:-NetService Methods
    
    //Initializes the receiver for publishing a network service
    func startBroadCasting(){
        service = NetService.init(domain: serviceValue.domain.rawValue, type: serviceValue.type.rawValue, name: UIDevice.current.name, port: Int32(BonjourService.portAddr))
        service.delegate = self
        service.publish()
    }
    
    //Starts a search for services
    func startSearchService() {
        self.devices.removeAll()
        self.coServiceBrowser = NetServiceBrowser()
        self.coServiceBrowser.delegate = self
        self.coServiceBrowser.searchForServices(ofType: serviceValue.type.rawValue, inDomain: serviceValue.domain.rawValue)
        self.coServiceBrowser.schedule(in: RunLoop.current, forMode: RunLoop.Mode.default)
    }
    
    // MARK: - NSNetService Delegates
    
    //Notifies the service was successfully published.
    func netServiceDidPublish(_ sender: NetService) {
        self.delegate.publishService(sender)
    }
    
    //Notifies the service was not successfully published.
    func netService(_ sender: NetService, didNotPublish errorDict: [String : NSNumber]) {
//        print("Unable to create socket. domain")
//        print(errorDict)
    }
    
    //To identify the sender found a service.
    func netServiceBrowser(_ aNetServiceBrowser: NetServiceBrowser, didFind aNetService: NetService, moreComing: Bool) {
        self.devices.append(aNetService)
        if !moreComing {
            aNetService.stop()
            self.delegate.scanService()
           //  print("netServiceDidResolveAddress",aNetService)
        }
    }
    
    //To identify the sender disappeared or has become unavailable.
    func netServiceBrowser(_ browser: NetServiceBrowser, didRemove service: NetService, moreComing: Bool){
        //print("didRemoveService")
        if let ix = self.devices.firstIndex(of: service) {
            self.devices.remove(at: ix)
          //  print("removing a service")
            if !moreComing {
                self.delegate.scanService()
            }
        }
    }
    
    //Informs that the address for a given service was resolved.
    func netServiceDidResolveAddress(_ sender: NetService) {
      //  print("netServiceDidResolveAddress",sender)
            self.delegate.scanService()
    }
    
}
