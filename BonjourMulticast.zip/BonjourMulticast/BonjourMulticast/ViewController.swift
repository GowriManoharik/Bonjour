//
//  ViewController.swift
//  BonjourMulticast
//
//  Created by Gowri on 14/07/20.
//  Copyright © 2020 Sample. All rights reserved.
//

import UIKit

enum serviceType : String {
    case publish = "publish"
    case scan = "scan"
}

private var bonjourService: BonjourService!

class ViewController: UIViewController,BonjourDelegate{
    
    //MARK:- IBOutLet
    @IBOutlet var tableView: UITableView!
    @IBOutlet var tableHeightConstraint: NSLayoutConstraint!
    
    //MARK:- Var
    var serviceData:[String] = []
    let cellReuseIdentifier = "tableViewCell"
   
    override func viewDidLoad() {
        // Do any additional setup after loading the view.
        super.viewDidLoad()
        bonjourService = BonjourService()
        
        bonjourService.delegate = self
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.isHidden = true
        
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        self.tableView.tableFooterView = UIView()
        
    }
    
    
    //MARK:- Button Action
    
    // Publish Button Action
    @IBAction func publishAction(_ sender: Any) {
        bonjourService.startBroadCasting()
    }
    
    // Scan Button Action
    @IBAction func scanAction(_ sender: Any) {
        bonjourService.devices = []
        bonjourService.startSearchService()
    }
    
    //MARK:- Methods
    
    //To show alert for the published service
    func publishService(_ body: NetService?) {
        if let device = body{
            let alert = UIAlertController(title: "Published Successfully", message: self.setServiceDetails(Service: serviceType.publish.rawValue, serviceName: device.name, deviceType: device.type, iPAddress: nil, portAddr: device.port), preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    //To scan the published service
    func scanService() {
        tableView.isHidden = false
        let devices = bonjourService.devices
        if serviceData.count > 0{
                serviceData = []
        }
        
        if devices.count > 0{
            for deviceVal in devices {
                if deviceVal.port == -1 {
                    deviceVal.delegate = bonjourService
                    deviceVal.resolve(withTimeout: 0.0)
                } else {
                    if let addressDetail = deviceVal.addresses{
                        var ipAdd = ""
                        for address in addressDetail{
                            let addressData = address as Data
                            var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                            
                            if getnameinfo((addressData as NSData).bytes.bindMemory(to: sockaddr.self, capacity: addressData.count), socklen_t(addressData.count),
                                           &hostname, socklen_t(hostname.count), nil, 0, NI_NUMERICHOST) == 0 {
                                if let numAddress = String(validatingUTF8: hostname) {
                                    ipAdd = numAddress
                                    // print( deviceVal.name)
                                    if ipAdd.isIPv4() && ipAdd != "127.0.0.1"{
                                        serviceData.append(setServiceDetails(Service: serviceType.scan.rawValue, serviceName: deviceVal.name, deviceType: deviceVal.type, iPAddress: ipAdd, portAddr: deviceVal.port))
                                        
                                    }
                                }
                            }
                        }
                    }
                     reloadTableview()
                }
            }
        }
    }
    
    //MARK:- Private
    //To list the published service
    func reloadTableview(){
            
            let defaultHeight : CGFloat = self.view.frame.size.height - 183.0
            tableHeightConstraint.constant = defaultHeight
            if tableView.contentSize.height >= self.view.frame.size.height
            {
                tableHeightConstraint.constant = tableView.contentSize.height + defaultHeight
                
            }else{
                tableHeightConstraint.constant = defaultHeight
            }
            tableView.reloadData()
            tableView.layoutIfNeeded()
           
    }
}


//MARK:- TableView
//TABLEVIEW DELEGATES

extension ViewController : UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.serviceData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = self.tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier)!
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.text = serviceData[indexPath.row]
        cell.textLabel?.font = UIFont.italicSystemFont(ofSize: 16)
        cellCustomize(cell: cell)
        return cell
    }
    
    //MARK:- Private
    //Customize tableview cell
    func cellCustomize(cell: UITableViewCell){
        cell.layer.cornerRadius = 10
        cell.backgroundColor = UIColor.systemPink
        cell.contentView.layer.masksToBounds = false
        cell.contentView.layer.shadowColor = UIColor.gray.cgColor
        cell.contentView.layer.shadowOffset =  CGSize.zero
        cell.contentView.layer.shadowOpacity = 0.5
        cell.contentView.layer.shadowRadius = 4
        cell.contentView.layer.cornerRadius = 12.0
        cell.contentView.layer.borderColor = UIColor.brown.cgColor
    }
    
}

//TABLEVIEW DATASOURCE
extension ViewController : UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

}

//MARK:- String
extension String {
    
    //To check valid ipaddress
    func isIPv4() -> Bool {
        var addr = sockaddr_in()
         return self.withCString({ cstring in inet_pton(AF_INET, cstring, &addr.sin_addr) }) == 1
       
    }
    
}

//MARK:- ViewController
extension ViewController{
    
    // format the String for display data
    func setServiceDetails(Service: String, serviceName: String, deviceType: String, iPAddress: String?, portAddr: Int) -> String{
        var setValue = String()
        if Service == serviceType.publish.rawValue{
            setValue = "Service Name - <\(serviceName)> \nService Type - <\(deviceType)> \nPort Address - <\(portAddr)>"
        }
        else if Service == serviceType.scan.rawValue{
            setValue =  "Service Name : \(serviceName) \nService Type : \(deviceType) \nIP Address : \(iPAddress ?? "") \nPort Address : \(portAddr)"
        }
        return setValue
    }
    
}
